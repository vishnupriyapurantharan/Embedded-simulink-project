#ifndef ACTIVITY3_H_INCLUDED
#define ACTIVITY3_H_INCLUDED
/**
 * @brief For defining activity3
 */
char Activity3();

#endif // ACTIVITY3_H_INCLUDED
